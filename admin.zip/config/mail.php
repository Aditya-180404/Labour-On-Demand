<?php
// SMTP Configuration
define('SMTP_HOST', 'smtp.gmail.com'); // Example: smtp.gmail.com
define('SMTP_USERNAME', 'aditya.roy180404@gmail.com'); // Replace with your email
define('SMTP_PASSWORD', 'wnri dtwp qaak vcpj'); // Replace with your App Password
define('SMTP_PORT', 587); // Usually 587 for TLS, 465 for SSL
define('SMTP_FROM_EMAIL', 'no-reply@labourondemand.com');
define('SMTP_FROM_NAME', 'Labour On Demand');
?>
